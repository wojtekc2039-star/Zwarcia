# -*- coding: utf-8 -*-
"""KOD MAIN_APP_010 – 2025-12-05
Główny plik startowy programu „Zwarcia” po modularyzacji CAD.

Uruchamiaj ZAWSZE TEN plik (F5 w VS Code).

Co robi:
- ustawia katalog roboczy na folder ZWARCIA,
- tworzy strukturę katalogów data/...,
- uruchamia logowanie startu do data/logi/app.log,
- tworzy okno MainWindow(data_folder=...) z modułu gui.main_window.
"""

import sys
import os
import datetime
from pathlib import Path

from PySide6.QtWidgets import QApplication

from gui.main_window import MainWindow


def get_program_directory() -> Path:
    """Zwraca katalog główny programu (obsługa trybu EXE / skrypt)."""
    if getattr(sys, "frozen", False):
        # Tryb EXE – katalog z plikiem wykonywalnym
        return Path(os.path.abspath(sys.executable)).parent
    # Tryb skryptu – katalog, w którym leży main_app.py
    return Path(__file__).resolve().parent


def ensure_data_folders():
    """Tworzy strukturę folderów data/... jeżeli nie istnieje.

    Zwraca tuple: (data_folder, lista_utworzonych_podfolderów).
    data_folder jest ścieżką do katalogu .../data jako string.
    """
    root = get_program_directory()
    data_path = root / "data"
    subfolders = [
        "projekty",
        "raporty",
        "szablony",
        "eksport",
        "import",
        "backup",
        "logi",
        "config",
    ]

    created = []
    try:
        data_path.mkdir(parents=True, exist_ok=True)
        for sub in subfolders:
            sub_path = data_path / sub
            if not sub_path.is_dir():
                sub_path.mkdir(parents=True, exist_ok=True)
                created.append(str(sub_path))
    except Exception as e:  # pragma: no cover
        print("Błąd tworzenia folderów danych:", e)

    return str(data_path), created


def write_log_start(data_folder: str) -> None:
    """Dopisuje wpis startowy do pliku logów data/logi/app.log."""
    log_file = Path(data_folder) / "logi" / "app.log"
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        with log_file.open("a", encoding="utf-8") as f:
            f.write(f"[{ts}] Start programu 'Zwarcia' (modularyzacja CAD).\n")
    except Exception as e:  # pragma: no cover
        print("Błąd zapisu logów:", e)


def main() -> int:
    """Główna funkcja startowa aplikacji."""
    # Ustawiamy katalog roboczy na folder ZWARCIA (tam gdzie leży ten plik)
    base_dir = get_program_directory()
    os.chdir(base_dir)

    # Tworzymy aplikację Qt
    app = QApplication(sys.argv)

    # Tworzenie struktury katalogów danych i start logowania
    data_folder, created_folders = ensure_data_folders()
    write_log_start(data_folder)

    # Tworzymy okno główne z wymaganym parametrem data_folder
    window = MainWindow(data_folder=data_folder)
    window.show()

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
