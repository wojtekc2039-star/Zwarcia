# -*- coding: utf-8 -*-
"""KOD GUI_MAIN_WINDOW_090 – 2025-12-05
Etap 8.6 – cienka nakładka na edytor CAD (cad.cad_editor.MainWindow).

Cel:
- odciążenie dużego pliku CAD,
- możliwość dokładania logiki zwarciowej / raportów w osobnym module GUI,
- zachowanie wszystkich bajerów CAD PRO++ z pliku cad/cad_editor.py.
"""

from cad.cad_editor import MainWindow as CadMainWindow


class MainWindow(CadMainWindow):
    """Główne okno programu „Zwarcia”.

    Dziedziczy w 100% zachowanie z :class:`cad.cad_editor.MainWindow`.
    W kolejnych etapach w tej klasie będziemy dopinać:
    - integrację z core.shortcircuit / core.reports,
    - dodatkowe okna i kreatory raportów,
    - ewentualne nowe przyciski menu / toolbary niezwiązane z samym CAD.
    """

    def __init__(self, data_folder: str) -> None:
        super().__init__(data_folder)
