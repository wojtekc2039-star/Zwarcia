# -*- coding: utf-8 -*-
"""
KOD GUI_EDITOR_SCENE_083 – 2025-12-04
Etap 8.3 – wydzielenie klasy EditorScene (QGraphicsScene) do osobnego modułu.

Na tym etapie:
- EditorScene jest cienkim wrapperem wokół QGraphicsScene,
- logika rysowania nadal znajduje się głównie w MainWindow/GraphicsView,
- celem jest uporządkowanie struktury i przygotowanie miejsca na późniejsze
  przeniesienie logiki sceny (np. obsługi łączenia elementów) do tej klasy.
"""

from PySide6.QtWidgets import QGraphicsScene


class EditorScene(QGraphicsScene):
    """
    Klasa sceny edytora schematu. Na razie nie dodaje dodatkowej logiki
    względem QGraphicsScene, ale w kolejnych etapach przeniesiemy tu
    operacje typowo "scenowe" (np. tworzenie połączeń, wyszukiwanie
    elementów, itp.).
    """

    def __init__(self, parent=None):
        # Możesz zmienić rozmiar sceny według uznania
        super().__init__(parent)
        # Ustawienie prostokąta sceny może być nadal wykonywane w MainWindow,
        # aby zachować zgodność z obecnym kodem.
        # self.setSceneRect(0, 0, 2000, 1500)
