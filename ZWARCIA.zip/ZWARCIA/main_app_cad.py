# KOD MAIN_APP_CAD_005 — 2025-12-05
# Osobny punkt startowy tylko dla nowego, modułowego edytora CAD.
# Nie dotyka głównego main_app.py ani obliczeń w core/.

import sys
from pathlib import Path

from PySide6.QtWidgets import QApplication

# Zakładamy, że ten plik leży w katalogu głównym projektu ZWARCIA/
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from cad.cad_editor import CadMainWindow  # noqa: E402


def main() -> int:
    app = QApplication(sys.argv)
    window = CadMainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
