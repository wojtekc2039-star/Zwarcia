# -*- coding: utf-8 -*-
"""
KOD CORE_REPORTS_R1_2 – 2025-12-04

Moduł odpowiedzialny za budowanie raportów tekstowych programu „Zwarcia”.

ETAP R1 / R1.2 / R2 – wersja dla:
- prostego zwarcia 3-fazowego (simple SC),
- zwarcia 3-fazowego w trybie Ybus.

Założenia:
- Logika obliczeń (R_k, X_k, |Z_k|, Iₖ″₃, Sk3, R/X, X/R) znajduje się w core.shortcircuit
  lub w kodzie GUI/Ybus.
- Ten moduł NIC nie liczy – tylko formatuje dane do czytelnej postaci tekstowej.
- Raport zawiera zawsze czytelne podsumowanie na końcu oraz marker
  "==== KONIEC RAPORTU ====".
"""

from __future__ import annotations

from typing import Dict, Iterable, List, Optional


def build_simple_sc_footer_block(
    results: Dict[str, float],
    footer_header: str = "Wynik w miejscu zwarcia (prosty tryb, ścieżka + źródło):",
) -> List[str]:
    """
    Zbuduj końcowy blok podsumowania dla prostego zwarcia 3-fazowego.

    Parametry:
        results:
            słownik z wynikami obliczeń zwarcia 3F, np.:
                R_k, X_k, Z_k_abs, Ik3_kA, Sk3_MVA, R_over_X, X_over_R.
        footer_header:
            nagłówek sekcji podsumowania (pierwsza linia bloku).

    Zwraca:
        listę linii tekstu (bez znaku nowej linii na końcu linii).
    """
    lines: List[str] = []

    R_k: Optional[float] = results.get("R_k")
    X_k: Optional[float] = results.get("X_k")
    Z_k_abs: Optional[float] = results.get("Z_k_abs")
    Ik3_kA: Optional[float] = results.get("Ik3_kA")
    Sk3_MVA: Optional[float] = results.get("Sk3_MVA")
    R_over_X: Optional[float] = results.get("R_over_X")
    X_over_R: Optional[float] = results.get("X_over_R")

    # pusta linia przed blokiem
    lines.append("")
    lines.append(footer_header)

    if R_k is not None:
        lines.append(f"  R_k = {R_k:.6f} Ω")
    if X_k is not None:
        lines.append(f"  X_k = {X_k:.6f} Ω")
    if Z_k_abs is not None:
        lines.append(f"  |Z_k| = {Z_k_abs:.6f} Ω")

    if Ik3_kA is not None:
        lines.append(f"  Iₖ″₃ = {Ik3_kA:.3f} kA (3-fazowe, początkowe, IEC 60909)")
    if Sk3_MVA is not None:
        lines.append(f"  Sk3 = {Sk3_MVA:.1f} MVA")

    if R_over_X is not None:
        lines.append(f"R_k/X_k = {R_over_X:.3f} (IEC 60909, R_k/X_k)")
    if X_over_R is not None:
        lines.append(f"X_k/R_k = {X_over_R:.3f} (IEEE, X_k/R_k)")

    return lines


def build_ybus_sc_footer_block(
    results: Dict[str, float],
    footer_header: str = "Wynik w miejscu zwarcia (tryb Ybus):",
) -> List[str]:
    """
    Blok podsumowania dla zwarcia 3F w trybie Ybus.

    Technicznie używa tego samego formatu co build_simple_sc_footer_block,
    ale z innym nagłówkiem. Dzięki temu końcówki raportów simple/Ybus
    są spójne, a jednocześnie w raporcie widać, w którym trybie liczono.
    """
    return build_simple_sc_footer_block(results, footer_header=footer_header)


def finalize_report(text_lines: Iterable[str]) -> str:
    """
    Zamień listę linii w finalny tekst raportu z gwarantowanym markerem
    "==== KONIEC RAPORTU ====" na końcu.

    Jeśli marker już występuje w tekście, nie jest dodawany drugi raz.
    """
    marker = "==== KONIEC RAPORTU ===="

    lines_list = list(text_lines)
    report_text = "\n".join(lines_list)

    if marker not in report_text:
        if not report_text.endswith("\n"):
            report_text += "\n"
        report_text += "\n" + marker + "\n"

    return report_text
