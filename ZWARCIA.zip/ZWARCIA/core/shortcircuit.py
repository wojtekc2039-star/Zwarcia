# -*- coding: utf-8 -*-
"""
KOD CORE_SHORTCIRCUIT_087 – 2025-12-04

Obliczenia zwarć 3-fazowych wg IEC 60909 (uproszczone) oraz
funkcje integrujące z innymi modułami core (network_model, transformers).
"""

from __future__ import annotations

from math import sqrt
from typing import Dict

from .network_model import NetworkModel
from .transformers import TransformerData, calc_transformer_impedance_ohm


def calc_iec60909_3ph_simple(
    Un_kV: float,
    Sk_MVA: float,
    r_x_src: float,
    R_path_ohm: float,
    X_path_ohm: float,
) -> Dict[str, float]:
    """
    Uproszczone obliczenie zwarcia 3-fazowego (początkowego) wg IEC 60909.

    Parametry:
        Un_kV:     napięcie znamionowe sieci w [kV],
        Sk_MVA:    moc zwarciowa w punkcie przyłączenia źródła [MVA],
        r_x_src:   stosunek R/X dla impedancji źródła (IEC – R/X),
        R_path_ohm: sumaryczna rezystancja toru zwarciowego [Ω],
        X_path_ohm: sumaryczna reaktancja toru zwarciowego [Ω].

    Zwraca słownik z kluczami m.in.:
        R_s, X_s – składowe źródła,
        R_k, X_k – składowe całkowite,
        Z_k_abs  – |Z_k|,
        Ik3_kA   – prąd zwarciowy 3F w [kA],
        Sk3_MVA  – moc zwarciowa 3F w [MVA],
        R_over_X – R_k / X_k,
        X_over_R – X_k / R_k.
    """
    if Un_kV <= 0 or Sk_MVA <= 0:
        raise ValueError("Un_kV i Sk_MVA muszą być dodatnie.")

    Un_V = Un_kV * 1e3
    Sk_VA = Sk_MVA * 1e6

    Zs_abs = Un_V**2 / Sk_VA  # |Z_s|

    if r_x_src < 0:
        raise ValueError("Stosunek R/X źródła nie może być ujemny.")

    if r_x_src == 0:
        R_s = 0.0
        X_s = Zs_abs
    else:
        X_s = Zs_abs / sqrt(1.0 + r_x_src**2)
        R_s = r_x_src * X_s

    R_k = R_s + R_path_ohm
    X_k = X_s + X_path_ohm

    Z_k_abs = sqrt(R_k**2 + X_k**2)

    if Z_k_abs == 0:
        raise ValueError("Impedancja zwarciowa Z_k nie może być zerowa.")

    # Ik"3 w kA
    Ik3_A = Un_V / (sqrt(3.0) * Z_k_abs)
    Ik3_kA = Ik3_A / 1000.0

    # Sk3 w MVA
    Sk3_VA = sqrt(3.0) * Un_V * Ik3_A
    Sk3_MVA = Sk3_VA / 1e6

    R_over_X = float("inf") if X_k == 0 else R_k / X_k
    X_over_R = float("inf") if R_k == 0 else X_k / R_k

    return {
        "R_s": R_s,
        "X_s": X_s,
        "R_k": R_k,
        "X_k": X_k,
        "Z_k_abs": Z_k_abs,
        "Ik3_kA": Ik3_kA,
        "Sk3_MVA": Sk3_MVA,
        "R_over_X": R_over_X,
        "X_over_R": X_over_R,
    }


def calc_iec60909_3ph_on_network(
    Un_kV: float,
    Sk_MVA: float,
    r_x_src: float,
    network: NetworkModel,
    src_node: str,
    fault_node: str,
) -> Dict[str, float]:
    """
    Zwarcie 3-fazowe na ścieżce w modelu sieci (NetworkModel).

    - Korzysta z NetworkModel.sum_path_impedance(...) do wyznaczenia
      całkowitego R_path i X_path.
    - Następnie wywołuje calc_iec60909_3ph_simple.

    Zwraca słownik wyników calc_iec60909_3ph_simple rozszerzony o:
        R_total_path, X_total_path – suma gałęzi na ścieżce.
    """
    path_imp = network.sum_path_impedance(src_node, fault_node)
    R_total = path_imp["R_total"]
    X_total = path_imp["X_total"]

    res = calc_iec60909_3ph_simple(
        Un_kV=Un_kV,
        Sk_MVA=Sk_MVA,
        r_x_src=r_x_src,
        R_path_ohm=R_total,
        X_path_ohm=X_total,
    )
    res.update(
        {
            "R_total_path": R_total,
            "X_total_path": X_total,
        }
    )
    return res


def calc_iec60909_3ph_with_transformer_and_line(
    Un_kV: float,
    Sk_MVA: float,
    r_x_src: float,
    trafo_data: TransformerData,
    R_line_ohm: float,
    X_line_ohm: float,
) -> Dict[str, float]:
    """
    Zwarcie 3F dla układu: źródło → transformator → linia/kabel → punkt zwarcia.

    - Najpierw oblicza impedancję transformatora w [Ω] za pomocą
      calc_transformer_impedance_ohm,
    - dodaje impedancję linii (R_line_ohm, X_line_ohm),
    - następnie wywołuje calc_iec60909_3ph_simple dla sumarycznej impedancji toru.

    Zwraca słownik jak calc_iec60909_3ph_simple rozszerzony o:
        R_tr_ohm, X_tr_ohm – składowe impedancji transformatora,
        R_line_ohm, X_line_ohm – impedancja linii.
    """
    R_tr, X_tr = calc_transformer_impedance_ohm(trafo_data)

    R_path = R_tr + R_line_ohm
    X_path = X_tr + X_line_ohm

    res = calc_iec60909_3ph_simple(
        Un_kV=Un_kV,
        Sk_MVA=Sk_MVA,
        r_x_src=r_x_src,
        R_path_ohm=R_path,
        X_path_ohm=X_path,
    )
    res.update(
        {
            "R_tr_ohm": R_tr,
            "X_tr_ohm": X_tr,
            "R_line_ohm": R_line_ohm,
            "X_line_ohm": X_line_ohm,
        }
    )
    return res
