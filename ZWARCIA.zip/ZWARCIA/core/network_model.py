# -*- coding: utf-8 -*-
"""
KOD CORE_NETWORK_MODEL_086 – 2025-12-04

Uproszczony model sieci oparty o networkx.

Celem tego modułu jest oddzielenie logiki budowy grafu sieci
(węzły, gałęzie, źródła) od warstwy GUI. Dzięki temu:
- obliczenia zwarciowe mogą korzystać z "czystego" modelu,
- GUI (MainWindow) jedynie wywołuje metody NetworkModel.

Uwaga:
- To jest szkielet, który można stopniowo wzbogacać o kolejne typy elementów
  (np. silniki, odbiorniki, uziemienia, itp.).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import networkx as nx


@dataclass
class BusbarNode:
    """Proste dane węzła szynowego."""

    node_id: str
    name: str
    voltage_kV: float


@dataclass
class BranchData:
    """Proste dane gałęzi (linia/kabel/trafo uproszczony do R/X)."""

    branch_id: str
    from_node: str
    to_node: str
    R_ohm: float
    X_ohm: float
    description: str = ""


class NetworkModel:
    """Warstwa pośrednia nad networkx.Graph dla programu „Zwarcia”."""

    def __init__(self) -> None:
        self.graph = nx.Graph()

    # --- WĘZŁY ---

    def add_busbar(self, data: BusbarNode) -> None:
        self.graph.add_node(
            data.node_id,
            kind="busbar",
            name=data.name,
            voltage_kV=data.voltage_kV,
        )

    # --- GAŁĘZIE ---

    def add_branch(self, data: BranchData) -> None:
        self.graph.add_edge(
            data.from_node,
            data.to_node,
            branch_id=data.branch_id,
            R_ohm=data.R_ohm,
            X_ohm=data.X_ohm,
            description=data.description,
        )

    def path_branches(self, src_node: str, dst_node: str) -> List[Dict[str, Any]]:
        """
        Znajdź ścieżkę pomiędzy src_node i dst_node i zwróć listę gałęzi
        (słowników z parametrami R/X).

        Rzuca networkx.NetworkXNoPath w razie braku ścieżki.
        """
        path = nx.shortest_path(self.graph, src_node, dst_node)
        branches: List[Dict[str, Any]] = []

        for u, v in zip(path[:-1], path[1:]):
            edge_data = self.graph.get_edge_data(u, v, default={})
            branches.append(
                {
                    "from": u,
                    "to": v,
                    "R_ohm": edge_data.get("R_ohm", 0.0),
                    "X_ohm": edge_data.get("X_ohm", 0.0),
                    "branch_id": edge_data.get("branch_id", ""),
                    "description": edge_data.get("description", ""),
                }
            )

        return branches

    def sum_path_impedance(self, src_node: str, dst_node: str) -> Dict[str, float]:
        """
        Pomocnicza funkcja: zwróć sumaryczne R_total, X_total dla ścieżki.
        """
        branches = self.path_branches(src_node, dst_node)
        R_total = sum(b["R_ohm"] for b in branches)
        X_total = sum(b["X_ohm"] for b in branches)
        return {"R_total": R_total, "X_total": X_total}
