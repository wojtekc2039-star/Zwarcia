# -*- coding: utf-8 -*-
"""
KOD CORE_TRANSFORMERS_085 – 2025-12-04

Moduł pomocniczy do obliczeń parametrów transformatorów.
Na tym etapie funkcje są proste i skupiają się na wyznaczeniu
impedancji transformatora w [Ω] po stronie niskiego napięcia,
na podstawie mocy znamionowej Sn, napięcia zwarcia Uk i napięcia znamionowego Un.

Wzory są zgodne z typowym podejściem IEC 60909 (uproszczonym):
    Z_tr = Uk[%] / 100 * Un[V]^2 / Sn[VA]

Rozkład Z_tr na R_tr i X_tr odbywa się poprzez zadany stosunek R/X.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple


@dataclass
class TransformerData:
    """Dane znamionowe transformatora uproszczone na potrzeby obliczeń."""

    Sn_MVA: float        # moc znamionowa [MVA]
    Un_kV: float         # napięcie znamionowe po stronie, do której przeliczamy [kV]
    Uk_percent: float    # napięcie zwarcia [%]
    r_over_x: float      # stosunek R/X transformatora (IEC 60909)


def calc_transformer_impedance_ohm(data: TransformerData) -> Tuple[float, float]:
    """
    Oblicz impedancję transformatora w [Ω] (R_tr, X_tr).

    Parametry:
        data: TransformerData – dane znamionowe transformatora.

    Zwraca:
        (R_tr, X_tr) – składowe rezystancyjna i reaktancyjna impedancji w [Ω].

    Uwaga:
    - Funkcja jest celowo prosta; w razie potrzeby można ją rozszerzyć
      o dokładniejsze modele (np. rozdzielenie R_cu, X_leak, itd.).
    """

    Sn_VA = data.Sn_MVA * 1e6
    Un_V = data.Un_kV * 1e3

    if Sn_VA <= 0 or Un_V <= 0:
        raise ValueError("Sn i Un muszą być dodatnie.")

    if data.Uk_percent <= 0:
        raise ValueError("Uk[%] musi być dodatnie.")

    Z_tr_abs = (data.Uk_percent / 100.0) * (Un_V**2) / Sn_VA

    r_over_x = data.r_over_x
    if r_over_x < 0:
        raise ValueError("Stosunek R/X nie może być ujemny.")

    if r_over_x == 0:
        R_tr = 0.0
        X_tr = Z_tr_abs
    else:
        # Z_tr^2 = R_tr^2 + X_tr^2, R_tr = r_over_x * X_tr
        # => Z_tr^2 = (r_over_x^2 + 1) * X_tr^2
        from math import sqrt

        X_tr = Z_tr_abs / sqrt(1.0 + r_over_x**2)
        R_tr = r_over_x * X_tr

    return R_tr, X_tr
