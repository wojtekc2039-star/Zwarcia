# -*- coding: utf-8 -*-
"""
Pakiet core – logika obliczeniowa programu „Zwarcia”.

Moduły:
- shortcircuit – obliczenia zwarć 3-fazowych (IEC 60909),
- transformers – pomocnicze obliczenia związane z transformatorami,
- network_model – warstwa pośrednia nad networkx (model sieci).

Uwaga:
- W trakcie etapów 8.x kod jest stopniowo przenoszony z pliku
  Zwarcia_54_ETAP7_4_BAJERY_CAD_PROPLUS_GUI_FIX.py.
"""
