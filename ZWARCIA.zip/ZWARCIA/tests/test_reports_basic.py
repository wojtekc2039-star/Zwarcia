# -*- coding: utf-8 -*-
"""
KOD TEST_REPORTS_BASIC_R1 – 2025-12-04

Podstawowe testy modułu core.reports dla prostego raportu zwarcia 3F.
"""

import unittest

from core.reports import build_simple_sc_footer_block, finalize_report


class TestReportsBasic(unittest.TestCase):
    def test_footer_block_structure(self):
        results = {
            "R_k": 0.123456,
            "X_k": 0.654321,
            "Z_k_abs": 0.666666,
            "Ik3_kA": 12.345,
            "Sk3_MVA": 250.0,
            "R_over_X": 0.1887,
            "X_over_R": 5.3000,
        }

        lines = build_simple_sc_footer_block(results)
        text = "\n".join(lines)

        # Sprawdzamy, czy zawiera kluczowe fragmenty
        self.assertIn("Wynik w miejscu zwarcia", text)
        self.assertIn("R_k = 0.123456 Ω", text)
        self.assertIn("X_k = 0.654321 Ω", text)
        self.assertIn("|Z_k| = 0.666666 Ω", text)
        self.assertIn("Iₖ″₃ = 12.345 kA", text)
        self.assertIn("Sk3 = 250.0 MVA", text)
        self.assertIn("R_k/X_k = 0.189", text)
        self.assertIn("X_k/R_k = 5.300", text)

    def test_finalize_report_adds_marker(self):
        lines = ["Linia 1", "Linia 2"]
        text = finalize_report(lines)
        self.assertIn("==== KONIEC RAPORTU ====", text)

    def test_finalize_report_does_not_duplicate_marker(self):
        lines = ["Linia 1", "==== KONIEC RAPORTU ===="]
        text = finalize_report(lines)
        self.assertEqual(text.count("==== KONIEC RAPORTU ===="), 1)


if __name__ == "__main__":
    unittest.main()
