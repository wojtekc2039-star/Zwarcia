# -*- coding: utf-8 -*-
"""
KOD TEST_NETWORK_MODEL_096 – 2025-12-04

Podstawowe testy modułu core.network_model.
"""

import unittest

from core.network_model import NetworkModel, BusbarNode, BranchData


class TestNetworkModelBasic(unittest.TestCase):
    def test_add_and_sum_path(self):
        nm = NetworkModel()

        nm.add_busbar(BusbarNode(node_id="BB1", name="Szyna 1", voltage_kV=15.0))
        nm.add_busbar(BusbarNode(node_id="BB2", name="Szyna 2", voltage_kV=15.0))

        nm.add_branch(
            BranchData(
                branch_id="BR1",
                from_node="BB1",
                to_node="BB2",
                R_ohm=0.02,
                X_ohm=0.06,
                description="Test branch",
            )
        )

        result = nm.sum_path_impedance("BB1", "BB2")
        self.assertAlmostEqual(result["R_total"], 0.02, places=6)
        self.assertAlmostEqual(result["X_total"], 0.06, places=6)


if __name__ == "__main__":
    unittest.main()
