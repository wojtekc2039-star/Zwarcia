# -*- coding: utf-8 -*-
"""
KOD TEST_IMPORTS_090 – 2025-12-04

Podstawowe testy "smoke tests" dla programu „Zwarcia”.

Cele:
- sprawdzić, czy moduły main_app i gui.main_window dają się poprawnie zaimportować,
- upewnić się, że klasa MainWindow istnieje,
- zweryfikować, że konstruktor MainWindow przyjmuje argument data_folder.

Uruchamianie testów (w folderze ZWARCIA):
    python -m unittest tests.test_imports_basic

UWAGA:
- Ten plik NIE uruchamia QApplication ani okna – testujemy tylko importy i sygnatury.
"""

import inspect
import importlib
import unittest


class TestBasicImports(unittest.TestCase):
    """Podstawowe testy importu modułów i klasy MainWindow."""

    def test_import_main_app(self):
        """Moduł main_app powinien dać się zaimportować bez wyjątków."""
        module = importlib.import_module("main_app")
        self.assertIsNotNone(module)

    def test_import_main_window(self):
        """Moduł gui.main_window i klasa MainWindow powinny istnieć."""
        module = importlib.import_module("gui.main_window")
        self.assertIsNotNone(module)

        MainWindow = getattr(module, "MainWindow", None)
        self.assertIsNotNone(MainWindow, "Brak klasy MainWindow w gui.main_window")

        # Sprawdzamy, czy konstruktor przyjmuje co najmniej argument data_folder
        sig = inspect.signature(MainWindow.__init__)
        params = list(sig.parameters.values())

        # Pierwszy parametr to self, drugi – data_folder
        self.assertGreaterEqual(
            len(params), 2,
            "MainWindow.__init__ powinien mieć co najmniej parametry (self, data_folder)"
        )
        self.assertEqual(params[0].name, "self")
        self.assertEqual(
            params[1].name,
            "data_folder",
            "Drugi parametr konstruktora powinien nazywać się 'data_folder'"
        )


if __name__ == "__main__":
    unittest.main()
