# -*- coding: utf-8 -*-
"""
KOD TEST_SHORTCIRCUIT_084 – 2025-12-04

Podstawowe testy funkcji core.shortcircuit.calc_iec60909_3ph_simple.

Uruchamianie testów (w folderze ZWARCIA):
    python -m unittest tests.test_shortcircuit_basic
"""

import unittest

from core.shortcircuit import calc_iec60909_3ph_simple


class TestShortCircuitBasic(unittest.TestCase):
    """Proste testy poprawności obliczeń zwarcia 3‑fazowego."""

    def test_pure_reactance_path_zero(self):
        """Gdy ścieżka ma R=X=0, wynik powinien zależeć tylko od źródła."""
        Un_kV = 15.0
        Sk_MVA = 500.0
        r_x = 0.1
        res = calc_iec60909_3ph_simple(Un_kV, Sk_MVA, r_x, R_path_ohm=0.0, X_path_ohm=0.0)

        self.assertGreater(res["Z_k_abs"], 0.0)
        self.assertIsNotNone(res["Ik3_kA"])
        self.assertIsNotNone(res["Sk3_MVA"])

    def test_symmetry_r_x_zero(self):
        """Przy R/X = 0 impedancja źródła jest czysto reaktancyjna (R_s ~ 0)."""
        Un_kV = 15.0
        Sk_MVA = 100.0
        r_x = 0.0
        res = calc_iec60909_3ph_simple(Un_kV, Sk_MVA, r_x, R_path_ohm=0.0, X_path_ohm=0.0)

        self.assertAlmostEqual(res["R_s"], 0.0, places=6)
        self.assertGreater(res["X_s"], 0.0)


if __name__ == "__main__":
    unittest.main()
