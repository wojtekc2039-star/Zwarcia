# -*- coding: utf-8 -*-
"""
KOD TEST_SC_CORE_INTEGRATION_097 – 2025-12-04

Testy integracyjne dla modułów core.shortcircuit, core.transformers,
core.network_model – sprawdzają współpracę modułów bez udziału GUI.
"""

import unittest

from core.shortcircuit import (
    calc_iec60909_3ph_on_network,
    calc_iec60909_3ph_with_transformer_and_line,
)
from core.transformers import TransformerData
from core.network_model import NetworkModel, BusbarNode, BranchData


class TestShortCircuitCoreIntegration(unittest.TestCase):
    def test_sc_on_network_single_branch(self):
        nm = NetworkModel()
        nm.add_busbar(BusbarNode(node_id="SRC", name="Źródło", voltage_kV=15.0))
        nm.add_busbar(BusbarNode(node_id="BB1", name="Szyna 1", voltage_kV=15.0))

        nm.add_branch(
            BranchData(
                branch_id="BR1",
                from_node="SRC",
                to_node="BB1",
                R_ohm=0.02,
                X_ohm=0.06,
                description="Linia testowa",
            )
        )

        res = calc_iec60909_3ph_on_network(
            Un_kV=15.0,
            Sk_MVA=250.0,
            r_x_src=0.1,
            network=nm,
            src_node="SRC",
            fault_node="BB1",
        )

        self.assertGreater(res["Ik3_kA"], 0.0)
        self.assertAlmostEqual(res["R_total_path"], 0.02, places=6)
        self.assertAlmostEqual(res["X_total_path"], 0.06, places=6)

    def test_sc_with_transformer_and_line(self):
        trafo = TransformerData(
            Sn_MVA=25.0,
            Un_kV=15.0,
            Uk_percent=10.0,
            r_over_x=0.1,
        )

        res = calc_iec60909_3ph_with_transformer_and_line(
            Un_kV=15.0,
            Sk_MVA=250.0,
            r_x_src=0.1,
            trafo_data=trafo,
            R_line_ohm=0.02,
            X_line_ohm=0.06,
        )

        self.assertGreater(res["Ik3_kA"], 0.0)
        self.assertGreater(res["Sk3_MVA"], 0.0)
        self.assertGreater(res["R_tr_ohm"], 0.0)
        self.assertGreater(res["X_tr_ohm"], 0.0)


if __name__ == "__main__":
    unittest.main()
