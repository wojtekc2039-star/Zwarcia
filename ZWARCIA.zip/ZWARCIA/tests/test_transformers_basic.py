# -*- coding: utf-8 -*-
"""
KOD TEST_TRANSFORMERS_095 – 2025-12-04

Podstawowe testy modułu core.transformers.
"""

import unittest

from core.transformers import TransformerData, calc_transformer_impedance_ohm


class TestTransformersBasic(unittest.TestCase):
    def test_calc_transformer_impedance_positive(self):
        data = TransformerData(
            Sn_MVA=25.0,
            Un_kV=15.0,
            Uk_percent=10.0,
            r_over_x=0.1,
        )
        R_tr, X_tr = calc_transformer_impedance_ohm(data)
        self.assertGreater(X_tr, 0.0)
        self.assertGreaterEqual(R_tr, 0.0)

    def test_invalid_parameters(self):
        data = TransformerData(
            Sn_MVA=0.0,
            Un_kV=15.0,
            Uk_percent=10.0,
            r_over_x=0.1,
        )
        with self.assertRaises(ValueError):
            calc_transformer_impedance_ohm(data)


if __name__ == "__main__":
    unittest.main()
