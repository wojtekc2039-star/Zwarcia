# -*- coding: utf-8 -*-
"""
Pakiet tests – testy jednostkowe programu „Zwarcia”.

Na początek trzymamy tutaj proste testy "smoke tests", które sprawdzają:
- czy moduły main_app i gui.main_window dają się poprawnie zaimportować,
- czy klasa MainWindow istnieje i ma poprawny podpis __init__(self, data_folder).

Kolejne etapy będą dodawały:
- testy obliczeń zwarciowych (core/shortcircuit.py),
- testy modeli transformatorów (core/transformers.py),
- testy raportów (core/reports.py).
"""
