# KOD CAD_INIT_001 — 2025-12-05
# Nowy, modułowy edytor CAD dla programu Zwarcia.

"""Pakiet cad – nowa, modułowa wersja edytora schematów.

Struktura:
- cad_items.py     – klasy elementów graficznych (szyna, linia).
- cad_view.py      – QGraphicsView z siatką, zoomem i snap-to-grid.
- cad_editor.py    – główne okno edytora CAD (menu, toolbar, statusbar).

Ten pakiet zastępuje stary, monolityczny edytor CAD. Obliczeń (core/*)
oraz raportów nie dotykamy – to tylko nowy edytor schematów.
"""
