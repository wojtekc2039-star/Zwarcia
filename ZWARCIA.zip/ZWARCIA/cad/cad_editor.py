# KOD CAD_EDITOR_008 — 2025-12-06
# Główne okno nowego, modułowego edytora CAD.
# Etap 6.1:
# - Dodano menu „Widok” z akcją „Przyciągaj do siatki” (anchor/środek).
# - Dodano menu „Edycja” z akcjami: Właściwości, Kopiuj, Wytnij, Wklej,
#   Duplikuj, Usuń, Zaznacz wszystko.
# - Akcje edycyjne są podpięte do publicznego API widoku (CadGraphicsView).
# - Zachowane skróty klawiaturowe i auto-powrót do wskaźnika po wstawieniach.

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtWidgets import (
    QGraphicsScene,
    QMainWindow,
    QStatusBar,
    QToolBar,
)

from .cad_view import CadGraphicsView, CadTool


class CadMainWindow(QMainWindow):
    """Proste główne okno edytora CAD (modułowa wersja)."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)

        self._create_scene_and_view()
        self._create_actions()
        self._create_menus()
        self._create_toolbar()
        self._create_status_bar()

        # Domyślne narzędzie – wskaźnik
        self.set_active_tool(CadTool.POINTER)

        # Po zakończeniu wstawiania elementu wracamy do wskaźnika
        self.view.toolFinished.connect(self._on_view_tool_finished)

        # Ustawienia okna
        self.setWindowTitle("Zwarcia – CAD (modułowa wersja testowa)")
        self.resize(1200, 800)  # << rozmiar startowy okna, możesz zmienić >>

    # ------------------------------------------------------------------
    # Inicjalizacja sceny i widoku
    # ------------------------------------------------------------------
    def _create_scene_and_view(self) -> None:
        self.scene = QGraphicsScene(self)
        # Duży obszar sceny – siatka widoczna w szerokim zakresie
        self.scene.setSceneRect(-5000, -5000, 10000, 10000)

        self.view = CadGraphicsView(self.scene, self)
        self.setCentralWidget(self.view)

    # ------------------------------------------------------------------
    # Akcje (narzędzia)
    # ------------------------------------------------------------------
    def _create_actions(self) -> None:
        self.action_pointer = QAction("Wskaźnik", self)
        self.action_pointer.setCheckable(True)
        self.action_pointer.setShortcut("1")
        self.action_pointer.setStatusTip("Wskaźnik – zaznaczanie i przesuwanie elementów")
        self.action_pointer.triggered.connect(lambda: self.set_active_tool(CadTool.POINTER))

        self.action_busbar = QAction("Szyna", self)
        self.action_busbar.setCheckable(True)
        self.action_busbar.setShortcut("2")
        self.action_busbar.setStatusTip("Szyna – LPM wstawia nową szynę (pod kursorem)")
        self.action_busbar.triggered.connect(lambda: self.set_active_tool(CadTool.BUSBAR))

        self.action_line = QAction("Linia", self)
        self.action_line.setCheckable(True)
        self.action_line.setShortcut("3")
        self.action_line.setStatusTip(
            "Linia – LPM na szynie, przeciągnij do drugiej szyny, LPM aby zakończyć"
        )
        self.action_line.triggered.connect(lambda: self.set_active_tool(CadTool.LINE))

        # --------------------------------------------------------------
        # Akcje edycyjne (Etap 5)
        # --------------------------------------------------------------
        self.action_edit_properties = QAction("Właściwości…", self)
        self.action_edit_properties.setStatusTip("Otwórz właściwości zaznaczonej szyny lub linii")
        self.action_edit_properties.triggered.connect(self.view.open_properties_for_selection)

        self.action_edit_copy = QAction("Kopiuj", self)
        self.action_edit_copy.setShortcut(QKeySequence.Copy)
        self.action_edit_copy.setStatusTip("Kopiuj zaznaczone elementy")
        self.action_edit_copy.triggered.connect(self.view.copy)

        self.action_edit_cut = QAction("Wytnij", self)
        self.action_edit_cut.setShortcut(QKeySequence.Cut)
        self.action_edit_cut.setStatusTip("Wytnij zaznaczone elementy")
        self.action_edit_cut.triggered.connect(self.view.cut)

        self.action_edit_paste = QAction("Wklej", self)
        self.action_edit_paste.setShortcut(QKeySequence.Paste)
        self.action_edit_paste.setStatusTip("Wklej elementy ze schowka")
        self.action_edit_paste.triggered.connect(self.view.paste)

        self.action_edit_duplicate = QAction("Duplikuj", self)
        self.action_edit_duplicate.setShortcut("Ctrl+D")
        self.action_edit_duplicate.setStatusTip("Duplikuj zaznaczone elementy")
        self.action_edit_duplicate.triggered.connect(self.view.duplicate)

        self.action_edit_delete = QAction("Usuń", self)
        self.action_edit_delete.setShortcut("Delete")
        self.action_edit_delete.setStatusTip("Usuń zaznaczone elementy")
        self.action_edit_delete.triggered.connect(self.view.delete_selection)

        self.action_edit_select_all = QAction("Zaznacz wszystko", self)
        self.action_edit_select_all.setShortcut(QKeySequence.SelectAll)
        self.action_edit_select_all.setStatusTip("Zaznacz wszystkie szyny i linie")
        self.action_edit_select_all.triggered.connect(self.view.select_all)

        # ------------------------------------------------------------------
        # Widok
        # ------------------------------------------------------------------
        self.action_view_snap = QAction("Przyciągaj do siatki", self)
        self.action_view_snap.setCheckable(True)
        self.action_view_snap.setStatusTip("Przyciągaj symbole do siatki względem środka/anchoru")
        self.action_view_snap.setChecked(self.view.is_snap_enabled())
        # triggered(bool) idealnie pasuje do set_snap_enabled(bool)
        self.action_view_snap.triggered.connect(self.view.set_snap_enabled)


    # ------------------------------------------------------------------
    # Menu
    # ------------------------------------------------------------------
    def _create_menus(self) -> None:
        view_menu = self.menuBar().addMenu("Widok")
        view_menu.addAction(self.action_view_snap)

        edit_menu = self.menuBar().addMenu("Edycja")

        edit_menu.addAction(self.action_edit_properties)
        edit_menu.addSeparator()
        edit_menu.addAction(self.action_edit_copy)
        edit_menu.addAction(self.action_edit_cut)
        edit_menu.addAction(self.action_edit_paste)
        edit_menu.addSeparator()
        edit_menu.addAction(self.action_edit_duplicate)
        edit_menu.addSeparator()
        edit_menu.addAction(self.action_edit_delete)
        edit_menu.addSeparator()
        edit_menu.addAction(self.action_edit_select_all)

    # ------------------------------------------------------------------
    # Toolbar
    # ------------------------------------------------------------------
    def _create_toolbar(self) -> None:
        toolbar = QToolBar("Narzędzia CAD", self)
        toolbar.setMovable(True)
        toolbar.setFloatable(True)

        # Tu możesz później zmienić ikonki / kolejność / styl
        toolbar.addAction(self.action_pointer)
        toolbar.addAction(self.action_busbar)
        toolbar.addAction(self.action_line)

        self.addToolBar(Qt.TopToolBarArea, toolbar)

    # ------------------------------------------------------------------
    # Status bar
    # ------------------------------------------------------------------
    def _create_status_bar(self) -> None:
        status = QStatusBar(self)
        self.setStatusBar(status)
        self._update_status_tool(CadTool.POINTER)

    # ------------------------------------------------------------------
    # Zmiana aktywnego narzędzia
    # ------------------------------------------------------------------
    def set_active_tool(self, tool: CadTool) -> None:
        """Ustawia aktywne narzędzie w GUI i w widoku."""
        # Odznacz wszystko
        self.action_pointer.setChecked(False)
        self.action_busbar.setChecked(False)
        self.action_line.setChecked(False)

        # Zaznacz właściwą akcję
        if tool == CadTool.POINTER:
            self.action_pointer.setChecked(True)
        elif tool == CadTool.BUSBAR:
            self.action_busbar.setChecked(True)
        elif tool == CadTool.LINE:
            self.action_line.setChecked(True)

        # Ustawiamy narzędzie w widoku
        self.view.set_tool(tool)
        self._update_status_tool(tool)

    # ------------------------------------------------------------------
    # Reakcja na zakończenie wstawiania elementu w widoku
    # ------------------------------------------------------------------
    def _on_view_tool_finished(self, finished_tool: CadTool) -> None:
        """Wywoływane, gdy widok zgłasza ukończenie rysowania.

        Logika:
        - Jeżeli zakończyło się wstawianie szyny lub linii (bez Shifta),
          przełączamy się na wskaźnik.
        """
        # Na razie niezależnie od tego, które narzędzie zakończyło rysowanie,
        # wracamy do wskaźnika – tak było w naszych ustaleniach.
        self.set_active_tool(CadTool.POINTER)

    # ------------------------------------------------------------------
    # Opis narzędzia w pasku statusu
    # ------------------------------------------------------------------
    def _update_status_tool(self, tool: CadTool) -> None:
        bar = self.statusBar()
        if tool == CadTool.POINTER:
            txt = "Narzędzie: Wskaźnik – zaznaczanie i przesuwanie elementów"
        elif tool == CadTool.BUSBAR:
            txt = (
                "Narzędzie: Szyna – LPM wstawia nową szynę pod kursorem; "
                "przytrzymaj Shift, aby wstawiać wiele szyn bez powrotu do wskaźnika"
            )
        elif tool == CadTool.LINE:
            txt = (
                "Narzędzie: Linia – LPM na szynie, przeciągnij do drugiej szyny, "
                "LPM aby zakończyć; ESC – anuluj; Ctrl+scroll – zoom; "
                "ŚPM lub Space+LPM – przesuwanie widoku; "
                "przytrzymaj Shift, aby rysować kilka linii pod rząd"
            )
        else:
            txt = "Narzędzie: nieznane"

        bar.showMessage(txt)