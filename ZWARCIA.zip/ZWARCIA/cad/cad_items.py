# KOD CAD_ITEMS_005 — 2025-12-06
# Podstawowe elementy graficzne: szyna + linia połączeniowa (QGraphicsLineItem)
# z obsługą listy połączeń i zaznaczania linii. Nowa, kompletna wersja dla modułowego CAD.

from __future__ import annotations

from typing import List, Optional

from PySide6.QtCore import QPointF, QRectF
from PySide6.QtGui import QBrush, QColor, QPen
from PySide6.QtWidgets import (
    QGraphicsItem,
    QGraphicsRectItem,
    QGraphicsLineItem,
)

# Ustawienia siatki i podstawowych rozmiarów
GRID_STEP: int = 20  # rozstaw siatki w pikselach
BUSBAR_WIDTH: int = 120
BUSBAR_HEIGHT: int = 16


class ConnectableRectItem(QGraphicsRectItem):
    """Bazowy prostokąt, do którego można podłączać linie.

    Utrzymuje listę połączeń (ConnectionLine) i aktualizuje je przy zmianie pozycji.

    Flagi:
    - ItemIsMovable – element można przesuwać,
    - ItemIsSelectable – element można zaznaczać,
    - ItemSendsGeometryChanges – zmiana położenia wywołuje itemChange().
    """

    def __init__(
        self,
        rect: QRectF,
        parent: Optional[QGraphicsItem] = None,
    ) -> None:
        super().__init__(rect, parent)
        self._connections: List["ConnectionLine"] = []

        self.setFlags(
            QGraphicsItem.ItemIsMovable
            | QGraphicsItem.ItemIsSelectable
            | QGraphicsItem.ItemSendsGeometryChanges
        )

    # --- Obsługa listy połączeń ---------------------------------------------
    @property
    def connections(self) -> List["ConnectionLine"]:
        return self._connections

    def add_connection(self, line: "ConnectionLine") -> None:
        if line not in self._connections:
            self._connections.append(line)

    def remove_connection(self, line: "ConnectionLine") -> None:
        if line in self._connections:
            self._connections.remove(line)

    # --- Geometria ----------------------------------------------------------
    def center_pos(self) -> QPointF:
        """Zwraca środek prostokąta w współrzędnych sceny."""
        return self.mapToScene(self.rect().center())

    # --- Reakcja na zmianę pozycji -----------------------------------------
    def itemChange(self, change: QGraphicsItem.GraphicsItemChange, value):
        # Gdy element został przesunięty – aktualizujemy wszystkie linie.
        if change == QGraphicsItem.ItemPositionHasChanged:
            for line in list(self._connections):
                try:
                    line.update_position()
                except RuntimeError:
                    # Linia mogła zostać już usunięta ze sceny.
                    pass
        return super().itemChange(change, value)


class BusbarItem(ConnectableRectItem):
    """Prosty symbol szyny (busbar) – poziomy prostokąt.

    Punkt (x, y) przekazany w konstruktorze jest środkiem szyny.
    """

    def __init__(
        self,
        x: float,
        y: float,
        width: float = BUSBAR_WIDTH,
        height: float = BUSBAR_HEIGHT,
        parent: Optional[QGraphicsItem] = None,
    ) -> None:
        # Prostokąt ustawiamy tak, aby (0,0) było w środku – ułatwia to center_pos().
        rect = QRectF(-width / 2.0, -height / 2.0, width, height)
        super().__init__(rect, parent)
        self.setPos(x, y)

        pen = QPen(QColor("#000000"))
        pen.setWidth(2)
        self.setPen(pen)
        self.setBrush(QBrush(QColor("#f0f0f0")))  # domyślny kolor szyny
        self.setZValue(1)  # szyna nad liniami


class ConnectionLine(QGraphicsLineItem):
    """Linia łącząca dwa elementy ConnectableRectItem.

    Linie są selektowalne i automatycznie podążają za elementami przy ich
    przesuwaniu (update_position wywoływane z itemChange elementów).
    """

    def __init__(
        self,
        start_item: ConnectableRectItem,
        end_item: ConnectableRectItem,
        parent: Optional[QGraphicsItem] = None,
    ) -> None:
        super().__init__(parent)
        self.start_item: ConnectableRectItem | None = start_item
        self.end_item: ConnectableRectItem | None = end_item

        pen = QPen(QColor("#000000"))
        pen.setWidth(2)
        self.setPen(pen)
        self.setZValue(0)

        self.setFlag(QGraphicsItem.ItemIsSelectable, True)

        # Rejestrujemy linię w obu elementach
        self.start_item.add_connection(self)
        self.end_item.add_connection(self)

        self.update_position()

    def update_position(self) -> None:
        """Aktualizuje położenie linii na podstawie pozycji elementów."""
        if self.start_item is None or self.end_item is None:
            return
        start = self.start_item.center_pos()
        end = self.end_item.center_pos()
        self.setLine(start.x(), start.y(), end.x(), end.y())

    # Pomocniczo – odpinanie linii od elementów (np. przy usuwaniu).
    def detach(self) -> None:
        if self.start_item is not None:
            self.start_item.remove_connection(self)
        if self.end_item is not None:
            self.end_item.remove_connection(self)
        self.start_item = None
        self.end_item = None
