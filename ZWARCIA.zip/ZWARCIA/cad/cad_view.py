# KOD CAD_VIEW_021 — 2025-12-06
# Widok CAD (QGraphicsView) dla programu „Zwarcia” – wersja modułowa.
# Etap 2:
# - Dwuklik na szynie otwiera okno „Właściwości szyny” (nazwa, napięcie kV, opis),
#   a etykieta z nazwą/napięciem wyświetla się przy szynie.
# - Dwuklik na linii otwiera okno „Właściwości linii” (nazwa, długość km,
#   R′ i X′ [Ω/km], opis), a etykieta z nazwą/długością wyświetla się przy linii.
# - Etykiety są niezależne od zoomu (ItemIgnoresTransformations).
# - Zachowane:
#   * narzędzia: wskaźnik / szyna / linia,
#   * auto-powrót do wskaźnika po wstawieniu elementu (bez Shift),
#   * zoom Ctrl+scroll,
#   * pan (ŚPM lub Space+LPM),
#   * stabilna siatka z cache tła.
#
# Parametry do łatwej regulacji:
# - startowy zoom: self._current_scale  (domyślnie 0.5 – mniejsze obiekty na starcie),
# - gęstość siatki: self._grid_size     (domyślnie 30 – odstęp linii siatki w jednostkach sceny).

from __future__ import annotations

from enum import Enum, auto
from typing import Optional

from PySide6.QtCore import Qt, QPointF, QRectF, Signal
from PySide6.QtGui import QPainter, QPen, QBrush, QAction, QKeySequence
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFormLayout,
    QGraphicsItem,
    QGraphicsLineItem,
    QGraphicsRectItem,
    QGraphicsScene,
    QGraphicsSimpleTextItem,
    QGraphicsView,
    QLineEdit,
    QPlainTextEdit,
    QVBoxLayout,
    QSizePolicy,
    QMenu,
)


class CadTool(Enum):
    """Narzędzia dostępne w widoku CAD."""
    POINTER = auto()
    BUSBAR = auto()
    LINE = auto()


class BusbarItem(QGraphicsRectItem):
    """Prosta szyna – prostokąt z możliwością zaznaczania i przesuwania.

    Linia łącząca szyny trzyma referencję do obiektów BusbarItem.
    Przy przesuwaniu szyny wszystkie podłączone linie aktualizują swoje położenie.
    """

    def __init__(
        self,
        width: float = 120.0,
        height: float = 20.0,
        parent: Optional[QGraphicsItem] = None,
    ) -> None:
        # Prostokąt centrowany wokół (0, 0); pozycję ustawiamy przez setPos().
        super().__init__(-width / 2.0, -height / 2.0, width, height, parent)

        self._connections: list[ConnectionLineItem] = []

        # Dane „elektryczne” / opisowe szyny
        self.name: str = ""          # np. "BB1"
        self.voltage_kv: float = 0.0 # np. 110.0
        self.description: str = ""   # opis / komentarz

        # Flagi pozwalające na zaznaczanie i przesuwanie szyny
        self.setFlags(
            QGraphicsItem.ItemIsSelectable
            | QGraphicsItem.ItemIsMovable
            | QGraphicsItem.ItemSendsGeometryChanges
        )

        # Wygląd szyny (możesz zmienić kolory wg uznania)
        pen = QPen()
        pen.setWidthF(2.0)
        self.setPen(pen)

        brush = QBrush()
        self.setBrush(brush)

        # Etykieta szyny – dziecko szyny, nie skaluje się z zoomem
        self._label_item = QGraphicsSimpleTextItem("", self)
        self._label_item.setFlag(QGraphicsItem.ItemIgnoresTransformations, True)
        self.update_label()

    # ------------------------------------------------------------------
    # Połączenia z liniami
    # ------------------------------------------------------------------
    def add_connection(self, line: "ConnectionLineItem") -> None:
        if line not in self._connections:
            self._connections.append(line)

    def remove_connection(self, line: "ConnectionLineItem") -> None:
        if line in self._connections:
            self._connections.remove(line)

    def connection_point(self) -> QPointF:
        """Punkt w przestrzeni sceny, do którego podpinamy linię."""
        return self.mapToScene(self.rect().center())

    # ------------------------------------------------------------------
    # Aktualizacja linii przy przesuwaniu szyny
    # ------------------------------------------------------------------
    def itemChange(self, change: QGraphicsItem.GraphicsItemChange, value):
        if change == QGraphicsItem.ItemPositionHasChanged:
            for line in list(self._connections):
                line.update_position()
        return super().itemChange(change, value)

    # ------------------------------------------------------------------
    # Etykieta szyny
    # ------------------------------------------------------------------
    def update_label(self) -> None:
        """Aktualizuje tekst i położenie etykiety szyny."""
        parts: list[str] = []
        if self.name:
            parts.append(self.name)
        if self.voltage_kv:
            parts.append(f"{self.voltage_kv:.0f} kV")
        label_text = " ".join(parts)
        self._label_item.setText(label_text)

        # Pozycja etykiety – nad szyną, wyśrodkowana
        rect = self.rect()
        br = self._label_item.boundingRect()
        x = rect.center().x() - br.width() / 2.0
        y = rect.top() - br.height() - 2.0  # 2 px odstępu
        self._label_item.setPos(x, y)


class ConnectionLineItem(QGraphicsLineItem):
    """Linia łącząca dwie szyny.

    Trzyma referencje do dwóch obiektów BusbarItem i aktualizuje swoją geometrię
    przy ich przesuwaniu. Ma własną etykietę (nazwa + długość km).
    """

    def __init__(
        self,
        start_item: BusbarItem,
        end_item: BusbarItem,
        parent: Optional[QGraphicsItem] = None,
    ) -> None:
        super().__init__(parent)
        self.setFlag(QGraphicsItem.ItemIsSelectable, True)
        self.start_item = start_item
        self.end_item = end_item

        pen = QPen()
        pen.setWidthF(2.0)
        self.setPen(pen)
        self.setZValue(-1)  # linia poniżej szyn

        # Dane linii
        self.name: str = ""          # np. "L1"
        self.length_km: float = 0.0  # długość linii [km]
        self.r_ohm_per_km: float = 0.0  # R' [Ω/km]
        self.x_ohm_per_km: float = 0.0  # X' [Ω/km]
        self.description: str = ""   # opis / komentarz

        # Etykieta linii – osobny item w scenie, nie skaluje się z zoomem
        self._label_item: Optional[QGraphicsSimpleTextItem] = None

        self.update_position()

    def _ensure_label_item(self) -> None:
        """Tworzy etykietę linii, jeśli jeszcze jej nie ma."""
        if self._label_item is None:
            scene = self.scene()
            if scene is None:
                return
            self._label_item = QGraphicsSimpleTextItem("")
            self._label_item.setFlag(QGraphicsItem.ItemIgnoresTransformations, True)
            scene.addItem(self._label_item)

    def update_label(self) -> None:
        """Aktualizuje tekst i położenie etykiety linii."""
        self._ensure_label_item()
        if self._label_item is None:
            return

        parts: list[str] = []
        if self.name:
            parts.append(self.name)
        if self.length_km:
            parts.append(f"{self.length_km:.2f} km")
        label_text = " ".join(parts)
        self._label_item.setText(label_text)

        # Pozycja etykiety – w środku linii
        p1 = self.start_item.connection_point()
        p2 = self.end_item.connection_point()
        mid_x = (p1.x() + p2.x()) / 2.0
        mid_y = (p1.y() + p2.y()) / 2.0
        br = self._label_item.boundingRect()
        self._label_item.setPos(mid_x - br.width() / 2.0, mid_y - br.height() / 2.0)

    def update_position(self) -> None:
        """Aktualizuje geometrię linii i położenie etykiety."""
        p1 = self.start_item.connection_point()
        p2 = self.end_item.connection_point()
        self.setLine(p1.x(), p1.y(), p2.x(), p2.y())
        self.update_label()


# ----------------------------------------------------------------------
# Okna właściwości
# ----------------------------------------------------------------------
class BusbarPropertiesDialog(QDialog):
    """Okno edycji właściwości szyny."""

    def __init__(self, bus: BusbarItem, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Właściwości szyny")
        self._bus = bus

        self.name_edit = QLineEdit(bus.name)
        self.voltage_spin = QDoubleSpinBox()
        self.voltage_spin.setRange(0.0, 1100.0)
        self.voltage_spin.setDecimals(1)
        self.voltage_spin.setSingleStep(1.0)
        self.voltage_spin.setValue(bus.voltage_kv)
        self.voltage_spin.setSuffix(" kV")

        self.desc_edit = QPlainTextEdit()
        self.desc_edit.setPlainText(bus.description)
        # Dynamiczne pole opisu – rozciąga się wraz z oknem dialogowym
        self.desc_edit.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        form = QFormLayout()
        # Pola formularza mogą się rozszerzać przy zmianie rozmiaru okna
        form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        form.addRow("Nazwa szyny:", self.name_edit)
        form.addRow("Napięcie [kV]:", self.voltage_spin)
        form.addRow("Opis / komentarz:", self.desc_edit)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout()
        layout.addLayout(form)
        layout.addWidget(buttons)
        self.setLayout(layout)
        self.resize(420, 320)  # początkowy rozmiar okna właściwości szyny

    def apply_to_item(self) -> None:
        """Zapisuje dane z formularza do obiektu szyny."""
        self._bus.name = self.name_edit.text().strip()
        self._bus.voltage_kv = float(self.voltage_spin.value())
        self._bus.description = self.desc_edit.toPlainText().strip()
        self._bus.update_label()

class LinePropertiesDialog(QDialog):
    """Okno edycji właściwości linii."""

    def __init__(self, line: ConnectionLineItem, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Właściwości linii")
        self._line = line

        self.name_edit = QLineEdit(line.name)

        self.length_spin = QDoubleSpinBox()
        self.length_spin.setRange(0.0, 1000.0)
        self.length_spin.setDecimals(3)
        self.length_spin.setSingleStep(0.1)
        self.length_spin.setValue(line.length_km)
        self.length_spin.setSuffix(" km")

        self.r_spin = QDoubleSpinBox()
        self.r_spin.setRange(0.0, 1000.0)
        self.r_spin.setDecimals(4)
        self.r_spin.setSingleStep(0.01)
        self.r_spin.setValue(line.r_ohm_per_km)
        self.r_spin.setSuffix(" Ω/km")

        self.x_spin = QDoubleSpinBox()
        self.x_spin.setRange(0.0, 1000.0)
        self.x_spin.setDecimals(4)
        self.x_spin.setSingleStep(0.01)
        self.x_spin.setValue(line.x_ohm_per_km)
        self.x_spin.setSuffix(" Ω/km")

        self.desc_edit = QPlainTextEdit()
        self.desc_edit.setPlainText(line.description)

        form = QFormLayout()
        form.addRow("Nazwa linii:", self.name_edit)
        form.addRow("Długość [km]:", self.length_spin)
        form.addRow("R′ [Ω/km]:", self.r_spin)
        form.addRow("X′ [Ω/km]:", self.x_spin)
        form.addRow("Opis / komentarz:", self.desc_edit)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout()
        layout.addLayout(form)
        layout.addWidget(buttons)
        self.setLayout(layout)

    def apply_to_item(self) -> None:
        """Zapisuje dane z formularza do obiektu linii."""
        self._line.name = self.name_edit.text().strip()
        self._line.length_km = float(self.length_spin.value())
        self._line.r_ohm_per_km = float(self.r_spin.value())
        self._line.x_ohm_per_km = float(self.x_spin.value())
        self._line.description = self.desc_edit.toPlainText().strip()
        self._line.update_label()


class CadGraphicsView(QGraphicsView):
    """Widok sceny CAD z obsługą narzędzi, zoomu, panningu, właściwości i siatki."""

    # Sygnał emitowany po zakończeniu wstawiania elementu (jeśli nie trzymamy Shift)
    # Przekazujemy obiekt typu CadTool jako "object", żeby uniknąć problemów z Enum.
    toolFinished = Signal(object)

    def __init__(self, scene: QGraphicsScene, parent=None) -> None:
        super().__init__(scene, parent)

        # Renderowanie z antyaliasingiem – poprawna składnia dla PySide6:
        self.setRenderHint(QPainter.Antialiasing, True)
        self.setRenderHint(QPainter.TextAntialiasing, True)
        self.setRenderHint(QPainter.SmoothPixmapTransform, True)

        # Cache tła + aktualizacja tylko zmienionych fragmentów
        self.setCacheMode(QGraphicsView.CacheBackground)
        self.setViewportUpdateMode(QGraphicsView.BoundingRectViewportUpdate)

        # Zoom
        self._zoom_factor_step: float = 1.15
        self._current_scale: float = 0.5  # startowy zoom – tu możesz regulować powiększenie początkowe
        self.scale(self._current_scale, self._current_scale)

        # Aktywne narzędzie
        self._current_tool: CadTool = CadTool.POINTER

        # Pan (przesuwanie widoku)
        self._is_panning: bool = False
        self._pan_start_pos = None
        self._space_pressed: bool = False

        # Rysowanie linii
        self._line_start_item: Optional[BusbarItem] = None
        self._temp_line_item: Optional[QGraphicsLineItem] = None

        # Siatka
        self._grid_size: int = 30  # odstęp między liniami siatki (w jednostkach sceny)

        # Tryb przeciągania – w trybie wskaźnika używamy RubberBandDrag
        self.setDragMode(QGraphicsView.RubberBandDrag)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)

        # Opcjonalne tło (na razie domyślne)
        self.setBackgroundBrush(QBrush())

        # ------------------------------------------------------------------
        # Wewnętrzny schowek CAD (kopiuj/wytnij/wklej) – niezależny od systemowego
        # ------------------------------------------------------------------
        self._cad_clipboard: Optional[dict] = None

        # ------------------------------------------------------------------
        # Tryb interaktywnego wklejania (PPM → Wklej)
        # W tym trybie obiekt/obiekty "przyklejają się" do kursora i są
        # wstawiane dopiero po kliknięciu LPM.
        # ------------------------------------------------------------------
        self._paste_mode_active: bool = False
        self._paste_payload: Optional[dict] = None
        self._paste_preview_busbars: list[QGraphicsRectItem] = []
        self._paste_preview_lines: list[QGraphicsLineItem] = []

    # ------------------------------------------------------------------
    # API dla okna głównego
    # ------------------------------------------------------------------
    def set_tool(self, tool: CadTool) -> None:
        """Ustawia aktualne narzędzie (wywoływane z CadMainWindow)."""
        self._current_tool = tool

        if tool == CadTool.POINTER:
            self.setDragMode(QGraphicsView.RubberBandDrag)
        else:
            self.setDragMode(QGraphicsView.NoDrag)

        # Anulujemy ewentualne tymczasowe rysowanie linii przy zmianie narzędzia
        self._cancel_temporary_line()

    # ------------------------------------------------------------------
    # Pomocnicze
    # ------------------------------------------------------------------
    def _busbar_at_view_pos(self, view_pos) -> Optional[BusbarItem]:
        item = self.itemAt(view_pos)
        while item is not None and not isinstance(item, BusbarItem):
            item = item.parentItem()
        return item if isinstance(item, BusbarItem) else None

    def _line_at_view_pos(self, view_pos) -> Optional[ConnectionLineItem]:
        item = self.itemAt(view_pos)
        while item is not None and not isinstance(item, ConnectionLineItem):
            item = item.parentItem()
        return item if isinstance(item, ConnectionLineItem) else None

    def _cancel_temporary_line(self) -> None:
        if self._temp_line_item is not None:
            scene = self.scene()
            if scene is not None:
                scene.removeItem(self._temp_line_item)
        self._temp_line_item = None
        self._line_start_item = None

    # ------------------------------------------------------------------
    # Edycja właściwości
    # ------------------------------------------------------------------
    def _edit_busbar_properties(self, bus: BusbarItem) -> None:
        dlg = BusbarPropertiesDialog(bus, self)
        if dlg.exec() == QDialog.Accepted:
            dlg.apply_to_item()

    def _edit_line_properties(self, line: ConnectionLineItem) -> None:
        dlg = LinePropertiesDialog(line, self)
        if dlg.exec() == QDialog.Accepted:
            dlg.apply_to_item()

    # ------------------------------------------------------------------
    # ZOOM – Ctrl + kółko myszy
    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # Selekcja i schowek CAD
    # ------------------------------------------------------------------
    def _selected_busbars(self) -> list[BusbarItem]:
        return [it for it in self.scene().selectedItems() if isinstance(it, BusbarItem)]

    def _selected_lines(self) -> list[ConnectionLineItem]:
        return [it for it in self.scene().selectedItems() if isinstance(it, ConnectionLineItem)]

    def _build_clipboard_payload_from_selection(self) -> Optional[dict]:
        """Buduje lekki payload do kopiowania.

        Kopiujemy tylko szyny. Linie kopiują się wyłącznie wtedy,
        gdy obie szyny końcowe są zaznaczone.
        """
        busbars = self._selected_busbars()
        if not busbars:
            return None

        # Anchor = środek zaznaczonych szyn (wspólny punkt odniesienia)
        rect = None
        for b in busbars:
            br = b.sceneBoundingRect()
            rect = br if rect is None else rect.united(br)
        if rect is None:
            return None
        anchor = rect.center()

        bus_data = []
        index_map = {}
        for idx, b in enumerate(busbars):
            r = b.rect()
            pos = b.pos()
            bus_data.append(
                {
                    "w": float(r.width()),
                    "h": float(r.height()),
                    "offset": (float(pos.x() - anchor.x()), float(pos.y() - anchor.y())),
                    "name": b.name,
                    "voltage_kv": float(b.voltage_kv),
                    "description": b.description,
                }
            )
            index_map[b] = idx

        line_data = []
        for ln in self._selected_lines():
            if ln.start_item in index_map and ln.end_item in index_map:
                line_data.append(
                    {
                        "start": index_map[ln.start_item],
                        "end": index_map[ln.end_item],
                        "name": ln.name,
                        "length_km": float(ln.length_km),
                        "r_ohm_per_km": float(ln.r_ohm_per_km),
                        "x_ohm_per_km": float(ln.x_ohm_per_km),
                        "description": getattr(ln, "description", ""),
                    }
                )

        return {"busbars": bus_data, "lines": line_data}

    def _has_clipboard_payload(self) -> bool:
        return bool(self._cad_clipboard and self._cad_clipboard.get("busbars"))

    def _action_copy(self) -> None:
        payload = self._build_clipboard_payload_from_selection()
        if payload:
            self._cad_clipboard = payload

    def _action_cut(self) -> None:
        payload = self._build_clipboard_payload_from_selection()
        if payload:
            self._cad_clipboard = payload
            self._action_delete()

    def _action_delete(self) -> None:
        """Usuwa zaznaczone elementy w bezpiecznej kolejności."""
        scene = self.scene()
        if scene is None:
            return

        # Najpierw linie, potem szyny
        for ln in self._selected_lines():
            try:
                scene.removeItem(ln)
            except Exception:
                pass

        for b in self._selected_busbars():
            # usuń wszystkie podłączone linie
            for ln in list(getattr(b, "_connections", [])):
                try:
                    scene.removeItem(ln)
                except Exception:
                    pass
            try:
                scene.removeItem(b)
            except Exception:
                pass

    def _action_duplicate(self, scene_anchor: Optional[QPointF] = None) -> None:
        payload = self._build_clipboard_payload_from_selection()
        if not payload:
            return

        # lekki offset jeśli nie podano anchoru
        if scene_anchor is None:
            # bazujemy na aktualnym centrum widoku
            scene_anchor = self.mapToScene(self.viewport().rect().center()) + QPointF(20, 20)

        self._finalize_paste_from_payload(payload, scene_anchor, select_new_only=True)

    # ------------------------------------------------------------------
    # Interaktywne wklejanie PPM
    # ------------------------------------------------------------------
    def _action_paste_interactive(self, scene_pos: QPointF) -> None:
        if not self._has_clipboard_payload():
            return
        self._begin_paste_interactive(self._cad_clipboard, scene_pos)

    def _begin_paste_interactive(self, payload: dict, scene_pos: QPointF) -> None:
        self._cancel_paste_mode()
        self._paste_mode_active = True
        self._paste_payload = payload
        self._create_paste_preview(payload)
        self._update_paste_preview(scene_pos)

    def _create_paste_preview(self, payload: dict) -> None:
        """Tworzy półprzezroczysty podgląd wklejanych obiektów."""
        scene = self.scene()
        if scene is None:
            return

        self._paste_preview_busbars = []
        self._paste_preview_lines = []

        # Podgląd szyn jako proste recty
        for b in payload.get("busbars", []):
            w = float(b.get("w", 120.0))
            h = float(b.get("h", 20.0))
            rect_item = QGraphicsRectItem(-w / 2.0, -h / 2.0, w, h)
            rect_item.setPen(QPen())
            rect_item.setBrush(QBrush())
            rect_item.setOpacity(0.35)
            rect_item.setZValue(10_000)  # zawsze na wierzchu
            scene.addItem(rect_item)
            self._paste_preview_busbars.append(rect_item)

        # Podgląd linii
        for ln in payload.get("lines", []):
            li = QGraphicsLineItem()
            li.setPen(QPen())
            li.setOpacity(0.35)
            li.setZValue(10_000)
            scene.addItem(li)
            self._paste_preview_lines.append(li)

    def _clear_paste_preview(self) -> None:
        scene = self.scene()
        if scene is None:
            self._paste_preview_busbars = []
            self._paste_preview_lines = []
            return

        for it in self._paste_preview_lines:
            try:
                scene.removeItem(it)
            except Exception:
                pass
        for it in self._paste_preview_busbars:
            try:
                scene.removeItem(it)
            except Exception:
                pass

        self._paste_preview_busbars = []
        self._paste_preview_lines = []

    def _update_paste_preview(self, scene_pos: QPointF) -> None:
        if not self._paste_mode_active or not self._paste_payload:
            return

        bus_payload = self._paste_payload.get("busbars", [])
        # ustaw pozycje podglądów szyn
        for idx, b in enumerate(bus_payload):
            if idx >= len(self._paste_preview_busbars):
                continue
            off = b.get("offset", (0.0, 0.0))
            x = scene_pos.x() + float(off[0])
            y = scene_pos.y() + float(off[1])
            self._paste_preview_busbars[idx].setPos(x, y)

        # ustaw geometrię podglądu linii
        for li_idx, ln in enumerate(self._paste_payload.get("lines", [])):
            if li_idx >= len(self._paste_preview_lines):
                continue
            s = int(ln.get("start", -1))
            e = int(ln.get("end", -1))
            if 0 <= s < len(self._paste_preview_busbars) and 0 <= e < len(self._paste_preview_busbars):
                p1 = self._paste_preview_busbars[s].sceneBoundingRect().center()
                p2 = self._paste_preview_busbars[e].sceneBoundingRect().center()
                self._paste_preview_lines[li_idx].setLine(p1.x(), p1.y(), p2.x(), p2.y())

    def _finalize_paste_from_payload(
        self,
        payload: dict,
        scene_pos: QPointF,
        select_new_only: bool = True,
    ) -> None:
        """Tworzy właściwe elementy z payloadu w danym miejscu sceny."""
        scene = self.scene()
        if scene is None:
            return

        new_busbars: list[BusbarItem] = []

        # 1) Szyny
        for b in payload.get("busbars", []):
            w = float(b.get("w", 120.0))
            h = float(b.get("h", 20.0))
            off = b.get("offset", (0.0, 0.0))
            bus = BusbarItem(width=w, height=h)
            bus.name = str(b.get("name", ""))
            bus.voltage_kv = float(b.get("voltage_kv", 0.0))
            bus.description = str(b.get("description", ""))
            bus.update_label()

            x = scene_pos.x() + float(off[0])
            y = scene_pos.y() + float(off[1])
            bus.setPos(x, y)
            scene.addItem(bus)
            new_busbars.append(bus)

        # 2) Linie
        new_lines: list[ConnectionLineItem] = []
        for ln in payload.get("lines", []):
            s = int(ln.get("start", -1))
            e = int(ln.get("end", -1))
            if 0 <= s < len(new_busbars) and 0 <= e < len(new_busbars):
                line = ConnectionLineItem(new_busbars[s], new_busbars[e])
                line.name = str(ln.get("name", ""))
                line.length_km = float(ln.get("length_km", 0.0))
                line.r_ohm_per_km = float(ln.get("r_ohm_per_km", 0.0))
                line.x_ohm_per_km = float(ln.get("x_ohm_per_km", 0.0))
                line.description = str(ln.get("description", ""))
                line.update_label()
                scene.addItem(line)
                new_lines.append(line)

        # Selektor UX: odznacz stare, zaznacz tylko nowe
        if select_new_only:
            scene.clearSelection()
            for b in new_busbars:
                b.setSelected(True)
            for ln in new_lines:
                ln.setSelected(True)

    def _finalize_interactive_paste(self, scene_pos: QPointF) -> None:
        if not self._paste_payload:
            return
        self._finalize_paste_from_payload(self._paste_payload, scene_pos, select_new_only=True)
        self._cancel_paste_mode()

    def _cancel_paste_mode(self) -> None:
        if self._paste_mode_active:
            self._clear_paste_preview()
        self._paste_mode_active = False
        self._paste_payload = None

    # ------------------------------------------------------------------
    # Menu kontekstowe (PPM)
    # ------------------------------------------------------------------
    def contextMenuEvent(self, event):
        scene_pos = self.mapToScene(event.pos())
        bus = self._busbar_at_view_pos(event.pos())
        line = self._line_at_view_pos(event.pos())

        menu = QMenu(self)

        # Właściwości – zależnie od obiektu pod kursorem
        if bus is not None:
            act_props = menu.addAction("Właściwości szyny…")
            act_props.triggered.connect(lambda: self._edit_busbar_properties(bus))
            menu.addSeparator()
        elif line is not None:
            act_props = menu.addAction("Właściwości linii…")
            act_props.triggered.connect(lambda: self._edit_line_properties(line))
            menu.addSeparator()

        # Zgodnie z Twoim wcześniejszym UX:
        # PPM na linię – bez Kopiuj/Wytnij/Wklej/Duplikuj
        if line is None:
            act_copy = menu.addAction("Kopiuj")
            act_copy.triggered.connect(self._action_copy)

            act_cut = menu.addAction("Wytnij")
            act_cut.triggered.connect(self._action_cut)

            act_dup = menu.addAction("Duplikuj")
            act_dup.triggered.connect(lambda: self._action_duplicate(scene_pos))

            menu.addSeparator()

            act_paste = menu.addAction("Wklej")
            act_paste.setEnabled(self._has_clipboard_payload())
            act_paste.triggered.connect(lambda: self._action_paste_interactive(scene_pos))

            menu.addSeparator()

        act_delete = menu.addAction("Usuń")
        act_delete.triggered.connect(self._action_delete)

        menu.addSeparator()

        act_sel_all = menu.addAction("Zaznacz wszystko")
        act_sel_all.triggered.connect(lambda: self.scene().selectAll())

        menu.exec(event.globalPos())
    def wheelEvent(self, event):
        if QApplication.keyboardModifiers() & Qt.ControlModifier:
            # Zoom z Ctrl+scroll
            angle = event.angleDelta().y()
            if angle > 0:
                factor = self._zoom_factor_step
            else:
                factor = 1.0 / self._zoom_factor_step

            self._current_scale *= factor
            self.scale(factor, factor)
            event.accept()
        else:
            # Normalne przewijanie
            super().wheelEvent(event)

    # ------------------------------------------------------------------
    # Pan – ŚPM lub Space + LPM
    # ------------------------------------------------------------------
    def _start_panning(self, event) -> None:
        self._is_panning = True
        self._pan_start_pos = event.pos()
        self.setCursor(Qt.ClosedHandCursor)
        event.accept()

    def _end_panning(self) -> None:
        self._is_panning = False
        self._pan_start_pos = None
        self.setCursor(Qt.ArrowCursor)

    # ------------------------------------------------------------------
    # Obsługa klawiatury
    # ------------------------------------------------------------------
    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Space:
            self._space_pressed = True
            event.accept()
            return


        # Tryb interaktywnego wklejania – ESC anuluje podgląd wklejania
        if self._paste_mode_active and event.key() == Qt.Key_Escape:
            self._cancel_paste_mode()
            event.accept()
            return
        if event.key() == Qt.Key_Escape:
            # ESC – anulowanie rysowania linii
            if self._temp_line_item is not None or self._line_start_item is not None:
                self._cancel_temporary_line()
                event.accept()
                return

        super().keyPressEvent(event)

    def keyReleaseEvent(self, event):
        if event.key() == Qt.Key_Space:
            self._space_pressed = False
            event.accept()
            return
        super().keyReleaseEvent(event)

    # ------------------------------------------------------------------
    # Obsługa myszy
    # ------------------------------------------------------------------
    def mousePressEvent(self, event):
        # Tryb interaktywnego wklejania (PPM → Wklej)
        if self._paste_mode_active and event.button() == Qt.LeftButton:
            self._finalize_interactive_paste(self.mapToScene(event.pos()))
            event.accept()
            return

        # Pan – ŚPM lub Space + LPM
        if event.button() == Qt.MiddleButton or (
            event.button() == Qt.LeftButton and self._space_pressed
        ):
            self._start_panning(event)
            return

        # Tryb wskaźnika – standardowe zachowanie
        if self._current_tool == CadTool.POINTER:
            super().mousePressEvent(event)
            return

        # Obsługujemy tylko LPM dla naszych narzędzi
        if event.button() != Qt.LeftButton:
            super().mousePressEvent(event)
            return

        scene_pos = self.mapToScene(event.pos())

        if self._current_tool == CadTool.BUSBAR:
            # Wstawienie szyny dokładnie pod kursorem (bez snapów, bez przesuwania widoku)
            bus = BusbarItem()
            bus.setPos(scene_pos)
            self.scene().addItem(bus)
            event.accept()

            # Jeśli nie trzymamy Shift – sygnał toolFinished (auto-powrót do wskaźnika)
            modifiers = QApplication.keyboardModifiers()
            continuous = bool(modifiers & Qt.ShiftModifier)
            if not continuous:
                self.toolFinished.emit(CadTool.BUSBAR)
            return

        if self._current_tool == CadTool.LINE:
            # LPM na szynie – start linii
            bus = self._busbar_at_view_pos(event.pos())
            if bus is not None:
                self._line_start_item = bus
                start_point = bus.connection_point()
                # Tymczasowa linia podczas przeciągania
                self._temp_line_item = QGraphicsLineItem(
                    start_point.x(),
                    start_point.y(),
                    start_point.x(),
                    start_point.y(),
                )
                pen = QPen()
                pen.setWidthF(2.0)
                self._temp_line_item.setPen(pen)
                self._temp_line_item.setZValue(-1)
                self.scene().addItem(self._temp_line_item)
                event.accept()
                return

        # W innych przypadkach delegujemy do bazowej implementacji
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        # Tryb interaktywnego wklejania – podgląd podąża za kursorem
        if self._paste_mode_active:
            self._update_paste_preview(self.mapToScene(event.pos()))
            event.accept()
            return

        # Pan
        if self._is_panning and self._pan_start_pos is not None:
            delta = event.pos() - self._pan_start_pos
            self._pan_start_pos = event.pos()
            self.horizontalScrollBar().setValue(
                self.horizontalScrollBar().value() - delta.x()
            )
            self.verticalScrollBar().setValue(
                self.verticalScrollBar().value() - delta.y()
            )
            event.accept()
            return

        # Rysowanie linii
        if (
            self._current_tool == CadTool.LINE
            and self._line_start_item is not None
            and self._temp_line_item is not None
        ):
            current_scene_pos = self.mapToScene(event.pos())
            start_point = self._line_start_item.connection_point()
            self._temp_line_item.setLine(
                start_point.x(),
                start_point.y(),
                current_scene_pos.x(),
                current_scene_pos.y(),
            )
            event.accept()
            return

        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        # Zakończenie panningu
        if self._is_panning and event.button() in (Qt.MiddleButton, Qt.LeftButton):
            self._end_panning()
            event.accept()
            return

        # Zakończenie rysowania linii
        if (
            self._current_tool == CadTool.LINE
            and event.button() == Qt.LeftButton
            and self._line_start_item is not None
            and self._temp_line_item is not None
        ):
            end_bus = self._busbar_at_view_pos(event.pos())
            if end_bus is not None and end_bus is not self._line_start_item:
                # Tworzymy ostateczną linię połączeniową
                line = ConnectionLineItem(self._line_start_item, end_bus)
                self.scene().addItem(line)
                self._line_start_item.add_connection(line)
                end_bus.add_connection(line)

            # Usuwamy tymczasową linię
            self.scene().removeItem(self._temp_line_item)
            self._temp_line_item = None
            self._line_start_item = None

            # Jeśli nie trzymamy Shift – sygnał toolFinished (auto-powrót do wskaźnika)
            modifiers = QApplication.keyboardModifiers()
            continuous = bool(modifiers & Qt.ShiftModifier)
            if not continuous:
                self.toolFinished.emit(CadTool.LINE)

            event.accept()
            return

        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        """Dwuklik: otwieranie okien właściwości dla szyn i linii."""
        item_bus = self._busbar_at_view_pos(event.pos())
        if item_bus is not None:
            self._edit_busbar_properties(item_bus)
            event.accept()
            return

        item_line = self._line_at_view_pos(event.pos())
        if item_line is not None:
            self._edit_line_properties(item_line)
            event.accept()
            return

        super().mouseDoubleClickEvent(event)

    # ------------------------------------------------------------------
    # Rysowanie tła – prosta, stabilna siatka
    # ------------------------------------------------------------------
    def drawBackground(self, painter: QPainter, rect: QRectF) -> None:
        super().drawBackground(painter, rect)

        painter.save()
        painter.setRenderHint(QPainter.Antialiasing, False)

        grid_size = self._grid_size

        # Zaokrąglamy do wielokrotności grid_size, żeby siatka była stabilna
        left = int(rect.left()) - (int(rect.left()) % grid_size)
        top = int(rect.top()) - (int(rect.top()) % grid_size)

        pen = QPen()
        pen.setWidth(1)
        painter.setPen(pen)

        x = left
        while x < rect.right():
            painter.drawLine(x, rect.top(), x, rect.bottom())
            x += grid_size

        y = top
        while y < rect.bottom():
            painter.drawLine(rect.left(), y, rect.right(), y)
            y += grid_size

        painter.restore()